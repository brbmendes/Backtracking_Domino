# Backtracking_Domino
Implementation of a Backtracking solution for Dominoes game using C#.

This project was created from a work of Complexity and Optimization discipline in the course of Computer Science from PUCRS.
